package de.test.jspwicket;

import org.apache.wicket.markup.html.WebPage;

public class TestPage2 extends WebPage {

    private static final long serialVersionUID = 3697359532920487023L;
}
