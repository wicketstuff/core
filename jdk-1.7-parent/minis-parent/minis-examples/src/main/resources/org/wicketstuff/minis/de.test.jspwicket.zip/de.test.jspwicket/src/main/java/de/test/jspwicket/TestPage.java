package de.test.jspwicket;

import org.apache.wicket.markup.html.WebPage;

public class TestPage extends WebPage {

    private static final long serialVersionUID = 1457592847439107204L;

}
